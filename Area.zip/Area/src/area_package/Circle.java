package area_package;

public class Circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int radius=4;
		float pi=(float) 3.14,area_cir;
		area_cir=pi*radius*radius;
		System.out.println("Area Of The Circle is:"+area_cir);
	}

}
