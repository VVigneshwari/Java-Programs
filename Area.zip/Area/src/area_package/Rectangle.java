package area_package;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int length=23,width=10,area_rect;
		area_rect=length*width;
		System.out.println("Area Of The Rectangle is:"+area_rect);

	}

}
