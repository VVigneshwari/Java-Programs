package area_package;

public class Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int height=12,base=3,area_tri;
		area_tri=(height*base)/2;
		System.out.println("Area Of Triangle is:"+area_tri);

	}

}
