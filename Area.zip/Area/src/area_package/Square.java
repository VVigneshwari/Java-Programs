package area_package;

public class Square {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=15,area_square;
		area_square=a*a;
		System.out.println("Area Of Square is:"+area_square);

	}

}
