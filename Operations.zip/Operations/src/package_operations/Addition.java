package package_operations;

public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=5,num2=4,res;
		res=num1+num2;
		System.out.println("The Addition of 2 Number:"+res);

	}

}
