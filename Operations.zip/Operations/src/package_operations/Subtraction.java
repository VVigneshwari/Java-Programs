package package_operations;

public class Subtraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=10,num2=6,res;
		res=num1-num2;
		System.out.println("The Subtraction of 2 Number:"+res);
	}

}
