package package_operations;

public class Multiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=5,num2=4,res;
		res=num1*num2;
		System.out.println("The Multiplication of 2 Number:"+res);
	}

}
