package package_operations;

public class Division {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=50,num2=4,res;
		res=num1/num2;
		System.out.println("The Division of 2 Number:"+res);
	}

}
